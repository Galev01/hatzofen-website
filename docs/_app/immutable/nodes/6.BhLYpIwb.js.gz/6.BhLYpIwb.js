import{f}from"../chunks/BwCF5TjU.js";export{f as component};
