import{d as m}from"../chunks/BwCF5TjU.js";export{m as component};
