import{a as e,_ as n}from"../chunks/BY-_P9oY.js";export{e as component,n as universal};
