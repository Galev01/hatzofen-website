import{_ as m}from"../chunks/Di5ZASl7.js";export{m as component};
