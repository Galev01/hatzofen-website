import{c as e}from"../chunks/msXI8ky7.js";export{e as component};
