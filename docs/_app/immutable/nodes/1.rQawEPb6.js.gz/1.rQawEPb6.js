import{V as m}from"../chunks/D8m-Qf3M.js";export{m as component};
