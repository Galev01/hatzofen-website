import{a as e,_ as n}from"../chunks/msXI8ky7.js";export{e as component,n as universal};
