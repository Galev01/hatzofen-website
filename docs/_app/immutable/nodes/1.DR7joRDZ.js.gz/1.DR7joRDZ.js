import{E as m}from"../chunks/B8ZAbbZG.js";export{m as component};
