import{d as m}from"../chunks/0Tkb-vzl.js";export{m as component};
