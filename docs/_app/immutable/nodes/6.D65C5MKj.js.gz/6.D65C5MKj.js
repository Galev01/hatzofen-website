import{_ as m}from"../chunks/D4dVVVh3.js";export{m as component};
