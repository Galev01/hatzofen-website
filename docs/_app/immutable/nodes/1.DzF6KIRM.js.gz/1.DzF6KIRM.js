import{R as m}from"../chunks/ClC967Ay.js";export{m as component};
