import{a as e,_ as n}from"../chunks/0Tkb-vzl.js";export{e as component,n as universal};
