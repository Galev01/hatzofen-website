import{d as m}from"../chunks/q7M8nvfz.js";export{m as component};
