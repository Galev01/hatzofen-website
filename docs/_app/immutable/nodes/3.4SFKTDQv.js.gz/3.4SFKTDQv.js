import{_ as m}from"../chunks/DkGyKQWz.js";export{m as component};
