import{c as e}from"../chunks/0Tkb-vzl.js";export{e as component};
