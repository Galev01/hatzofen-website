import{_ as m}from"../chunks/C4E56NBM.js";export{m as component};
