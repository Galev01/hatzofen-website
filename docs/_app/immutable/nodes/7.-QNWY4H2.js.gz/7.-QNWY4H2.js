import{g as m}from"../chunks/CbEbbm8I.js";export{m as component};
