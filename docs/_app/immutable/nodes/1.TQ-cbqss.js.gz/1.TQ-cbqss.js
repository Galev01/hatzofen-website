import{V as m}from"../chunks/CF0XajH-.js";export{m as component};
