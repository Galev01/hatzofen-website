import{R as m}from"../chunks/DhJ2NQXu.js";export{m as component};
