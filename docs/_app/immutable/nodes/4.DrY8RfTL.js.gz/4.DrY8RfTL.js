import{a as e}from"../chunks/C-jnm4S1.js";export{e as component};
