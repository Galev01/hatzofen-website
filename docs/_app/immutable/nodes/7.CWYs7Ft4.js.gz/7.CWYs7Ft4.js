import{g as m}from"../chunks/BY-_P9oY.js";export{m as component};
