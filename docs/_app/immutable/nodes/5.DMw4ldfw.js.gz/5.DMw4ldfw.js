import{_ as m}from"../chunks/DUg9uLm7.js";export{m as component};
