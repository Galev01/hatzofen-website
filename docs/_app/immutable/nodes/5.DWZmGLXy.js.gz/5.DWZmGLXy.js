import{_ as m}from"../chunks/WFXB-P9l.js";export{m as component};
