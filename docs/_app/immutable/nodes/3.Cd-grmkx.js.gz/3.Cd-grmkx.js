import{c as e}from"../chunks/q7M8nvfz.js";export{e as component};
