import{E as m}from"../chunks/DJR7BCqR.js";export{m as component};
