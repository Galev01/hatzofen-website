import{E as m}from"../chunks/kHkGlWGN.js";export{m as component};
