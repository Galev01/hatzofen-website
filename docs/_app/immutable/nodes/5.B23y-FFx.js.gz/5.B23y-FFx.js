import{e as m}from"../chunks/CbEbbm8I.js";export{m as component};
