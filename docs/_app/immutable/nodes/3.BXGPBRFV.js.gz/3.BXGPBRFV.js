import{c as e}from"../chunks/CbEbbm8I.js";export{e as component};
