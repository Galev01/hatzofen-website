import{V as m}from"../chunks/BRmUMiZ3.js";export{m as component};
