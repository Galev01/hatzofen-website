import{f}from"../chunks/CbEbbm8I.js";export{f as component};
