import{f}from"../chunks/0Tkb-vzl.js";export{f as component};
