import{V as m}from"../chunks/DUVIQDUP.js";export{m as component};
