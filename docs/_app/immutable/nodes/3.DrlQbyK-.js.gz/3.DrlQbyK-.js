import{_ as m}from"../chunks/kLu_mCjA.js";export{m as component};
