import{f}from"../chunks/msXI8ky7.js";export{f as component};
