import{R as m}from"../chunks/BJi779Lu.js";export{m as component};
