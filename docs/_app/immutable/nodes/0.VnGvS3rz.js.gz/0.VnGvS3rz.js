import{a as e,_ as n}from"../chunks/q7M8nvfz.js";export{e as component,n as universal};
