import{c as e}from"../chunks/BwCF5TjU.js";export{e as component};
