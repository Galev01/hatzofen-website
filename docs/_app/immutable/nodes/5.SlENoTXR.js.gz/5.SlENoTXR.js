import{e as m}from"../chunks/msXI8ky7.js";export{m as component};
