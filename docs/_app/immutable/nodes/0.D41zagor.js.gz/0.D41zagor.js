import{a as e,_ as n}from"../chunks/CbEbbm8I.js";export{e as component,n as universal};
