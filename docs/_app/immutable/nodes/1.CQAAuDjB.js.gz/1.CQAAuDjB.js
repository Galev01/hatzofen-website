import{V as m}from"../chunks/DFAJBdf9.js";export{m as component};
