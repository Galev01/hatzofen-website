import{e as m}from"../chunks/0Tkb-vzl.js";export{m as component};
