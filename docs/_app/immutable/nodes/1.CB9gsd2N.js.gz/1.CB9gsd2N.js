import{V as m}from"../chunks/Bh6MOdwG.js";export{m as component};
