import{E as m}from"../chunks/Bf7249Pj.js";export{m as component};
