import{_ as m}from"../chunks/B4RzSFBA.js";export{m as component};
