import{V as m}from"../chunks/DdXmkEau.js";export{m as component};
