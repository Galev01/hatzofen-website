import{_ as m}from"../chunks/D3XjMbr4.js";export{m as component};
