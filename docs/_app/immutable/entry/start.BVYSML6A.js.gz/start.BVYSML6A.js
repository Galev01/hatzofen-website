import{a3 as o,a2 as r}from"../chunks/DUVIQDUP.js";export{o as load_css,r as start};
