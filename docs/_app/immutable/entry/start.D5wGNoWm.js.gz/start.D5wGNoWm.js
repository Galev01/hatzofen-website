import{S as o,R as r}from"../chunks/kHkGlWGN.js";export{o as load_css,r as start};
