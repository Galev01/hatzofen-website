import{a4 as o,a3 as r}from"../chunks/ClC967Ay.js";export{o as load_css,r as start};
