import{R as o,Q as r}from"../chunks/BpX74gvl.js";export{o as load_css,r as start};
