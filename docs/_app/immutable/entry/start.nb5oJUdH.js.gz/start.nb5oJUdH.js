import{a4 as o,a3 as r}from"../chunks/B6yX5Elp.js";export{o as load_css,r as start};
