import{a3 as o,a2 as r}from"../chunks/D8m-Qf3M.js";export{o as load_css,r as start};
