import{S as o,R as r}from"../chunks/Bf7249Pj.js";export{o as load_css,r as start};
