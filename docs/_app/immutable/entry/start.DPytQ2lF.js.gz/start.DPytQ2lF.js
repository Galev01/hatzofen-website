import{S as o,R as r}from"../chunks/B8ZAbbZG.js";export{o as load_css,r as start};
